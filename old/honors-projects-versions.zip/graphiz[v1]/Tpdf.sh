dot -Tpdf 'out.dot' > 'out.pdf'
