python3 honors-project.py
dot -Tpdf 'out.dot' > 'out.pdf'
