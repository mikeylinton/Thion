import re
#dotFile=["digraph G {\n"]

class player:
  def __init__(self, name, auth):
    self.name = name
    self.auth = auth

def players(player):
    #player.split
    name,auth = player.split(":")
    p1 = Person(name, auth)
    print(p1.name)
    print(p1.auth) 

txtfile = open('t3gui.pyni', 'r')
count = 0
while True:
    count +=1
    line=txtfile.readline()
    if not line:
        break
    if not re.search("#.*", line):
        if re.search("^\[.*\]", line):
            print(line)
    if re.search("[Players]", line):
        while not re.search("^:", line):
            i+=1
            line=txtfile.readline()
    if not re.search("#.*", line):
        print(line)
txtfile.close()

#Saving to file.
outFile = open('out.dot', 'w')
outFile.writelines(dotFile)
outFile.close()