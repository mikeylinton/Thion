#LADDER DIAGRAM
import re as ree
from graphviz import Digraph as Dot
import argparse as ap
authority={"name":[],"digit":[]};
G=Dot()
#	#	#	#	#	#
#c0 = Dot('cluster_0')
#c0.body.append('style=filled')
#c0.body.append('color=lightgrey')
#c0.node_attr.update(style='filled', color='white')
#c0.edge('a0', 'a1')
#c0.edge('a1', 'a2')
#c0.edge('a2', 'a3')
#c0.body.append('label = "process #1"')

#c1 = Dot('cluster_1')
#c1.node_attr.update(style='filled')
#c1.edge('b0', 'b1')
#c1.edge('b1', 'b2')
#c1.edge('b2', 'b3')
#c1.edge('b3', 'b2')
#c1.body.append('label = "process #2"')
#c1.body.append('color=blue')
#c0.subgraph(c1)
#G.subgraph(c0)
#c0.subgraph(c1)
#	#	#	#	#	#
G.body.append('ranksep=".1"; nodesep=".1"; splines="line";')

inputfile=open('graph.in', 'r')
count=0
section=''
while True:
	line=inputfile.readline().strip()
	if not line:
		break
	count+=1
	if ree.search("^.*;$",line):
		items=ree.split(';+', line)
		items.remove('')
		for item in items:

			if section=="Environment":
				a,b=item.split('[')
				b=b.strip(']')
#				G.body.append('subgraph "cluster_'+a+'" {')
				vars()[a] = Dot('cluster_"'+a+'"')
				rooms=ree.split(',',b)
				for room in rooms:
					G.body.append('subgraph "cluster_'+room+'" {')
					G.body.append('label="'+room+'"')
					G.body.append('}')
#				G.body.append('}')

			if ree.search("^.* and .*$",item):
				a,b=item.split(' and ')
				print(f"Line",count,":",a,b)
			else:
				print(f"Line",count,":",item)
	elif ree.search("^\[.*\]$",line):
		item=line.strip('[').strip(']')
		sections=("Environment","Players","Pre-conditions","Main-flow","Post-conditions")
		if item in sections:
			section=item
			print(f"Line",count,":",line)
		else:
			print(f'\n',"Unknown section type",line,"on line",count,'\n',"Section types: [Environment] , [Players] , [Pre-conditions] , [Main-flow] , [Post-conditions]",'\n')
	else:
		print(f'\n',"BAD SYNTAX:",line,"on line",count,'\n')


#def subgraph(label, activitys):
#	with G.subgraph(name='cluster_'+str(label)) as X:
#		if isinstance(activitys, list):
#			for activity in activitys:
#				X.node(activity.strip())
#		elif activitys.strip() == '':
#			G.body.append('#No activitys')
#		else:
#			X.node(activitys.strip())
#		X.attr(label=label)


def _enviroment(line, num):
#	for line in enviroment:
	if ree.search("^.* \[.*\]", line):
		building=ree.sub(" \[.*\]", "", line)
		print(building)
		rooms=ree.sub("^.* ", "", line)
		print(rooms)
	elif ree.search("^.*[^\[]", line):
		subgraph(line)
	else:
		print(f"Syntax error: Line ",num)

def _players(line):
	print(line)
	#player,digit=line.split('=')
	print(digit)
	#subgraph(player, player)
	#authority[player]=digit

def _preconditions(line):
	return 0


#inputfile=open('graph.in', 'r')
#count=0
#while True:
#	line=inputfile.readline().strip()
#	count+=1
#	if not line:
#		break
#	if not ree.search("^#.*", line):
#		if ree.search("^\[.*\]", line):
#			if ree.search("^\[Enviroment\]", line):
#				line=inputfile.readline().strip()


##
#G.body.append('}')
print(G)
outFile=open('out.dot', 'w')
outFile.write(str(G))
outFile.close()
#print(f"Total number of lines:",count)
