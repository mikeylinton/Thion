#!/usr/bin/python3
#import os
import graphviz
graphviz.Source.from_file('dotFile.dot')
#print("give me a bottle of rum!")

dotFile = open('dotFile.dot', 'w') 
#l = ["(๑و•̀ω•́)و\n", "•ᴗ•\n", "(∩｀-´)⊃━☆ﾟ.*･｡ﾟ\n"] 
#s = ";-;\n"
#dotFile.write(s)
#dotFile.writelines(l)
dot=["digraph G {\n", "main -> parse -> execute;\n", "main -> init;\n", "main -> cleanup;\n", "execute -> make_string;\n", "execute -> printf\n", "init -> make_string;\n", "main -> printf;\n", "execute -> compare;\n", "}"]
dotFile.writelines(dot)
dotFile.close()

dotFile = open('dotFile.dot', 'r')
print(dotFile.read())
dotFile.close()
