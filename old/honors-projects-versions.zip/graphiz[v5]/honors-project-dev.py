import re;from graphviz import Digraph as Dot
#G=Dot()
#G.body.append('rankdir=LR;ranksep="0.2";nodesep="0.5";splines="line";edge[style=dotted;dir=none;fontsize=8];node[style=invis;shape=point;fontsize=10];')

inputfile=open('dev.in','r')

section=None
environment=[]
player_authority={}
player_messages={}
player_location={}
location_state={}
flow_timeline=[]


while True:
	line=inputfile.readline().strip()
	if not line:
		break

	if re.search("^\[.*\]$",line):
		item=line.strip('[').strip(']')
		sections=(
		"Environment",
		"Players",
		"Pre-conditions",
		"Main-flow",
		"Post-conditions")
		if item in sections:
			section=item
		else:
			print(f'\n',"Unknown section type:",line,'\n',"Section types: [Environment] , [Players] , [Pre-conditions] , [Main-flow] , [Post-conditions]",'\n')
		line=inputfile.readline().strip()


	if re.search("^.*;$",line) and not re.search("^#",line):
		items=re.split(';+',line)
		items.remove('')
		for item in items:
			if section=="Environment":
#"Building_A" [style="" shape=none label="Building A\nlock"];"0(Building_A)" [style=""];"Building_A" -> "0(Building_A)" [style=invis]
				i=len(environment)
				environment.append([])
				building,rooms=item.split('[')
				rooms=rooms.strip(']')
				rooms=re.split(',',rooms)
				building=building.replace(' ', '_')
				environment[i].append(building)
				for room in rooms:
					room=room.replace(' ', '_')
					environment[i].append(room)

			elif section=="Pre-conditions":

			elif section=="Players":
				if re.search('^.*\[.*\]$',item):
					head,tail=item.split('[')
					messages=tail.strip(']')
					player,authority=head.split('(')
					authority=authority.strip(')')
					messages=re.split(',',messages)
					player_messages[player]=messages
				else:
					player,authority=item.split('(')
					authority=authority.strip(')')
					messages=None
				player_messages[player]=messages
				player_authority[player]=authority

			elif section=="Main-flow":
				i=len(flow_timeline)
				flow_timeline.append([])
				action,elements=item.split('(')
				elements=elements.strip(')')
				elements=re.split(',',elements)
				flow_timeline[i].append(action)
				for element in elements:
					flow_timeline[i].append(element)
			
#			elif section=="Post-conditions":
	elif not re.search("^#",line):
		print(f'\n',"Unexpected error:",line,'\n')

print(environment)
for facilitys in environment:
	print(facilitys)
	building=facilitys.pop(0)
	print(building)
#	G.body.append('"'+building+'" [style="" shape=none label="'+building.replace('_', ' ')+'\\nlock"];"0('+building+')" [style=""];"'+building+'" -> "0('+building+')" [style=invis]')
	for room in facilitys:
		print(room)
#		G.body.append('"'+tail+'" [style="" shape=none label="'+tail.replace('_', ' ')+'\\nlock"];"0('+tail+')" [style=""];"'+tail+'" -> "0('+tail+')" [style=invis]')

print(player_authority)
for player in player_authority:
	print(player)
	player_location[player]=None
#	G.body.append('"'+player+'" [style="" shape=none label="'+player.replace('_', ' ')+'\\n('+player_authority[player]+')"];"0('+player+')" [style=""];"'+player+'" -> "0('+player+')" [style=invis]')

print(flow_timeline)
for string in flow_timeline:
	print(string)
	action=string.pop(0)
	print(action)

	if action=="enter":
		player=string.pop(0)
		print(player)
		facility=string.pop(0)
		print(facility)

	if action=="exit":
		player=string.pop(0)
		print(player)
		facility=string.pop(0)
		print(facility)

	if action=="lock":
		player=string.pop(0)
		print(player)
		facility=string.pop(0)
		print(facility)

	if action=="unlock":
		player=string.pop(0)
		print(player)
		facility=string.pop(0)
		print(facility)

#	G.body.append('"'+building+'" [style="" shape=none label="'+building.replace('_', ' ')+'\\nlock"];"0('+building+')" [style=""];"'+building+'" -> "0('+building+')" [style=invis]')
#	for tail in string:
#		print(tail)
#		G.body.append('"'+tail+'" [style="" shape=none label="'+tail.replace('_', ' ')+'\\nlock"];"0('+tail+')" [style=""];"'+tail+'" -> "0('+tail+')" [style=invis]')


#for items in environment:
#	building='cluster_'+items.pop(0)
#	for room in items:
#		room=building+'_'+room
#		vars()[building].subgraph(vars()[room])
#	G.subgraph(vars()[building])
#print(G)
#outFile=open('dev.out.dot', 'w')
#outFile.write(str(G))
#outFile.close()