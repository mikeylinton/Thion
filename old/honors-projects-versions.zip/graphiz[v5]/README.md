# honors-project
sample.in -> graphiz.py -> out.dot -> out.pdf
