import re
dotFile=["digraph G {\n"]

def graph(cluster, label):
	dotFile.append('subgraph cluster'+cluster+' {\n')
	dotFile.append('label = "'+label+'";\n')

def subgraph(cluster, label):
	dotFile.append('subgraph cluster'+cluster+' {\n')
	dotFile.append('label = "'+label+'";\n')
	dotFile.append('"'+label+'"')
	dotFile.append('}\n')

txtfile = open('meetingRoom.txt', 'r')
count = 0
while True:
	count += 1
	line = txtfile.readline()
	if not line:
		break
	if not re.search("#.*", line):
		if re.search("^\[.*\]", line):
			print(line)
			#line = txtfile.readline()
			if re.search(".*:\n", line):
				graph(str(count), line.strip().replace(':', ''))
			else:
				subgraph(str(count), line.strip())
		#print("Line{}: {}".format(count, line.strip()))
txtfile.close()
#env("Hello world")
dotFile.append('}\n')
dotFile.append('}')
print(dotFile)
outFile = open('out.dot', 'w')
outFile.writelines(dotFile)
outFile.close()
