'''
LADDER DIAGRAM
'''
import re as ree
from graphviz import Digraph as Dot
import argparse as ap
authority={"name":[],"digit":[]}
G=Dot()
'''
c0 = Dot('cluster_0')
c0.body.append('style=filled')
c0.body.append('color=lightgrey')
c0.node_attr.update(style='filled', color='white')
c0.edge('a0', 'a1')
c0.edge('a1', 'a2')
c0.edge('a2', 'a3')
c0.body.append('label = "process #1"')

c1 = Dot('cluster_1')
c1.node_attr.update(style='filled')
c1.edge('b0', 'b1')
c1.edge('b1', 'b2')
c1.edge('b2', 'b3')
c1.edge('b3', 'b2')
c1.body.append('label = "process #2"')
c1.body.append('color=blue')
c0.subgraph(c1)
G.subgraph(c0)
c0.subgraph(c1)
'''
G.body.append('ranksep=".1"; nodesep=".1"; splines="line"; node [shape=point fontsize=10]; edge [dir=none fontsize=10]')

inputfile=open('sample.in', 'r')
count=0
section=''
buildings=[]
while True:
	line=inputfile.readline().strip()
	if not line:	#EOF
		break
	count+=1
	if ree.search("^.*;$",line):
		items=ree.split(';+', line)
		items.remove('')
		for item in items:

			if section=="Environment":
				#a==building/main-enclave b==rooms/sub-enclave
				n=len(buildings)
				buildings.append([])
				a,b=item.split('[')
				labelA=a
				buildings[n].append(labelA)
				a='cluster_'+a.replace(' ', '_')
				b=b.strip(']')
				vars()[a] = Dot(a)
				vars()[a].body.append('label="'+labelA+'"')
				rooms=ree.split(',',b)
				for room in rooms:
					labelB=room
					buildings[n].append(labelB)
					room='cluster_'+room.replace(' ', '_')
					vars()[room] = Dot(room)
					vars()[room].body.append('label="'+labelB+'"')
#					vars()[a].subgraph(vars()[room])
			if section=="Main-flow":
#			print(item)
				action,objects=item.split('(')
				objects=objects.strip(')')
				objects=ree.split(',',objects)

				if action=="enter":
					is_building=False
					cluster='cluster_'+objects[1].replace(' ', '_')
					for items in buildings:
						if items[0]==objects[1]:
							is_building=True
							break
					if is_building:
						vars()[cluster].body.append(objects[0]+' [shape=none]')
					else: #room
						timeindex='timeindex_'+objects[1].replace(' ', '_')	#room time index
#						print(type(vars()[timeindex]))
						
						try:
							vars()[timeindex]=vars()[timeindex]+1
							vars()[cluster].edge(str(vars()[timeindex]-1)+'('+objects[1]+')', str(vars()[timeindex])+'('+objects[1]+')')
							vars()[cluster].edge(str(vars()[timeindex]-1)+'('+objects[0]+')', str(vars()[timeindex])+'('+objects[0]+')')
							#match prev to next eg: for index=1 => 0(Alice) to 1(Alice)
						except:
							vars()[timeindex]=0
							vars()[cluster].node(str(vars()[timeindex])+'('+objects[1]+')')
							vars()[cluster].node(str(vars()[timeindex])+'('+objects[0]+')')
							#match index to current eg: Alice to 0(Alice)
#							vars()[cluster].body.append('"'+objects[1]+' -> '+str(vars()[timeindex]+1)+'('+objects[1]+')"')

						vars()[cluster].body.append('{ rank=same; edge[style=invis] "'+str(vars()[timeindex])+'('+objects[1]+')" -> "'+str(vars()[timeindex])+'('+objects[0]+')" }')
#					cluster=cluster.strip()
#					print('<<'+cluster+'>>')
					
#					cluster_main_building.body.append(objects[0])

	elif ree.search("^\[.*\]$",line):
		item=line.strip('[').strip(']')
		sections=(
		"Environment",
		"Players",
		"Pre-conditions",
		"Main-flow",
		"Post-conditions")
		if item in sections:
			section=item
			print(f"Line",count,":",line)
		else:
			print(f'\n',"Unknown section type",line,"on line",count,'\n',"Section types: [Environment] , [Players] , [Pre-conditions] , [Main-flow] , [Post-conditions]",'\n')
	else:
		print(f'\n',"BAD SYNTAX:",line,"on line",count,'\n')

for items in buildings:
	building='cluster_'+items.pop(0).replace(' ', '_')
	print(building)
	for room in items:
		room='cluster_'+room.replace(' ', '_')
		vars()[building].subgraph(vars()[room])
		print(room)
	G.subgraph(vars()[building])
print(G)
outFile=open('out.dot', 'w')
outFile.write(str(G))
outFile.close()
#print(f"Total number of lines:",count)